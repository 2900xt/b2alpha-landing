"""
B2Alpha Python SDK

Connect AI agents to the B2Alpha network — register, discover,
message, and transact with other agents in under 30 lines of code.

Quickstart::

    import asyncio
    from b2alpha import Agent, AgentConfig

    async def main():
        agent = Agent(AgentConfig(
            did="did:b2a:zMyAgentDID",
            private_key_path="~/.b2alpha/agent.pem",
            node_url="wss://node.b2alpha.ai/v1/connect",
        ))

        async with agent:
            # Discover a flight booking agent
            results = await agent.phonebook.search("flight booking agent")
            target = results[0]

            # Send a message
            response = await agent.send(
                to=target.did,
                intent="book.flight",
                params={"from": "NYC", "to": "LAX", "date": "2026-03-01"},
            )
            print(response)

    asyncio.run(main())
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from b2alpha.agent import Agent
    from b2alpha.config import AgentConfig
    from b2alpha.identity import AgentIdentity
    from b2alpha.messages import AgentMessage, Envelope

__version__ = "0.1.0"

__all__ = [
    "Agent",
    "AgentConfig",
    "AgentIdentity",
    "generate_keypair",
    "Envelope",
    "AgentMessage",
]


def __getattr__(name: str) -> Any:
    if name == "Agent":
        from b2alpha.agent import Agent

        return Agent
    if name == "AgentConfig":
        from b2alpha.config import AgentConfig

        return AgentConfig
    if name == "AgentIdentity":
        from b2alpha.identity import AgentIdentity

        return AgentIdentity
    if name == "generate_keypair":
        from b2alpha.identity import generate_keypair

        return generate_keypair
    if name == "Envelope":
        from b2alpha.messages import Envelope

        return Envelope
    if name == "AgentMessage":
        from b2alpha.messages import AgentMessage

        return AgentMessage
    raise AttributeError(f"module 'b2alpha' has no attribute '{name}'")
