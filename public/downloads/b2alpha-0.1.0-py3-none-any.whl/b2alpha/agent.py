"""Agent — the main client class for connecting to the B2Alpha network."""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any, Callable, Awaitable

import websockets
from websockets.asyncio.client import ClientConnection

from b2alpha.config import AgentConfig
from b2alpha.identity import AgentIdentity
from b2alpha.messages import AgentMessage, DeliveryGuarantee, Envelope, MessageType

logger = logging.getLogger(__name__)

# Type alias for message handlers
MessageHandler = Callable[[Envelope], Awaitable[None]]


class Agent:
    """A B2Alpha agent connection.

    Use as an async context manager::

        async with Agent(config) as agent:
            await agent.send(to="did:b2a:z...", intent="book.flight", params={...})

    Or manage the connection lifecycle manually::

        agent = Agent(config)
        await agent.connect()
        ...
        await agent.disconnect()
    """

    def __init__(self, config: AgentConfig, identity: AgentIdentity | None = None) -> None:
        self.config = config
        self.identity = identity or AgentIdentity.from_pem(config.private_key_path)
        self._conn: ClientConnection | None = None
        self._recv_task: asyncio.Task[None] | None = None
        self._pending: dict[str, asyncio.Future[Envelope]] = {}
        self._handlers: list[MessageHandler] = []

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the WebSocket connection and authenticate."""
        logger.info("connecting to %s as %s", self.config.node_url, self.identity.did)

        self._conn = await websockets.connect(
            self.config.node_url,
            open_timeout=self.config.connect_timeout,
        )

        # Send connect frame
        await self._conn.send(json.dumps({
            "agent_did": self.identity.did,
            "session_token": await self._get_session_token(),
            "replay_undelivered": self.config.replay_undelivered,
        }))

        # Wait for connection ack
        raw = await asyncio.wait_for(
            self._conn.recv(), timeout=self.config.connect_timeout
        )
        ack = json.loads(raw)
        if "error" in ack:
            raise ConnectionError(f"Connection rejected: {ack['error']}")

        logger.info("connected — agent_did=%s", self.identity.did)

        # Start background receiver
        self._recv_task = asyncio.create_task(self._recv_loop())

    async def disconnect(self) -> None:
        """Close the connection gracefully."""
        if self._recv_task:
            self._recv_task.cancel()
            try:
                await self._recv_task
            except asyncio.CancelledError:
                pass

        if self._conn:
            await self._conn.close()
            self._conn = None

        logger.info("disconnected")

    async def __aenter__(self) -> "Agent":
        await self.connect()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.disconnect()

    # ------------------------------------------------------------------
    # Sending
    # ------------------------------------------------------------------

    async def send(
        self,
        *,
        to: str,
        intent: str,
        params: dict[str, str] | None = None,
        natural_language: str = "",
        correlation_id: str = "",
        delivery: DeliveryGuarantee = DeliveryGuarantee.AT_LEAST_ONCE,
        ttl_seconds: int = 300,
        wait_for_response: bool = True,
        response_timeout: float | None = None,
    ) -> Envelope | None:
        """Send a message to another agent.

        Args:
            to: Recipient agent DID.
            intent: Action string, e.g. ``"book.flight"``.
            params: Key-value parameters for the intent.
            natural_language: Optional human-readable description.
            correlation_id: Message ID to reply to (for threaded conversations).
            delivery: Delivery guarantee level.
            ttl_seconds: Message time-to-live.
            wait_for_response: If True, block until a correlated response arrives.
            response_timeout: Timeout in seconds for the response (default: config.request_timeout).

        Returns:
            The response Envelope if wait_for_response is True, else None.
        """
        if self._conn is None:
            raise RuntimeError("Agent is not connected. Call connect() first.")

        message = AgentMessage(
            intent=intent,
            params=params or {},
            natural_language=natural_language,
        )

        envelope = Envelope.build(
            sender_did=self.identity.did,
            recipient_did=to,
            message=message,
            sign_fn=self.identity.sign,
            correlation_id=correlation_id,
            delivery=delivery,
            ttl_seconds=ttl_seconds,
        )

        if wait_for_response:
            future: asyncio.Future[Envelope] = asyncio.get_event_loop().create_future()
            self._pending[envelope.message_id] = future

        await self._conn.send(json.dumps(envelope.to_dict()))
        logger.debug("sent message_id=%s to=%s intent=%s", envelope.message_id, to, intent)

        if wait_for_response:
            timeout = response_timeout or self.config.request_timeout
            try:
                return await asyncio.wait_for(future, timeout=timeout)
            except asyncio.TimeoutError:
                self._pending.pop(envelope.message_id, None)
                raise TimeoutError(
                    f"No response from {to} within {timeout}s for message {envelope.message_id}"
                )

        return None

    # ------------------------------------------------------------------
    # Receiving
    # ------------------------------------------------------------------

    def on_message(self, handler: MessageHandler) -> MessageHandler:
        """Register a message handler (decorator or direct call).

        The handler is called for every inbound message that isn't
        a response to a pending send() call.

        Example::

            @agent.on_message
            async def handle(envelope: Envelope) -> None:
                print(f"Got message: {envelope.message_id}")
        """
        self._handlers.append(handler)
        return handler

    async def _recv_loop(self) -> None:
        """Background task: receive inbound messages and dispatch them."""
        assert self._conn is not None

        try:
            async for raw in self._conn:
                try:
                    data = json.loads(raw)
                    envelope = self._parse_envelope(data)
                    await self._dispatch(envelope)
                except Exception as exc:
                    logger.warning("error processing inbound message: %s", exc)
        except websockets.exceptions.ConnectionClosed:
            logger.info("connection closed")

    def _parse_envelope(self, data: dict[str, Any]) -> Envelope:
        import base64
        from datetime import datetime, timezone

        return Envelope(
            message_id=data["message_id"],
            sender_did=data["sender_did"],
            recipient_did=data["recipient_did"],
            payload=base64.b64decode(data.get("payload", "")),
            signature=data.get("signature", ""),
            type=MessageType(data.get("type", 0)),
            delivery=DeliveryGuarantee(data.get("delivery", 0)),
            correlation_id=data.get("correlation_id", ""),
            routing_key=data.get("routing_key", ""),
            protocol_version=data.get("protocol_version", "0.1"),
            hop_count=data.get("hop_count", 0),
        )

    async def _dispatch(self, envelope: Envelope) -> None:
        # If this is a response to a pending send(), resolve the future
        if envelope.correlation_id and envelope.correlation_id in self._pending:
            future = self._pending.pop(envelope.correlation_id)
            if not future.done():
                future.set_result(envelope)
            return

        # Otherwise dispatch to registered handlers
        for handler in self._handlers:
            try:
                await handler(envelope)
            except Exception as exc:
                logger.exception("message handler raised: %s", exc)

    # ------------------------------------------------------------------
    # Auth helpers
    # ------------------------------------------------------------------

    async def _get_session_token(self) -> str:
        """Register with the phonebook and return the session token.

        Calls RegisterAgent on the phonebook gRPC server.  The request is
        authenticated by an Ed25519 signature over SHA-256(did || public_key || timestamp).
        On success, the phonebook stores the agent record in Supabase and returns
        a session UUID used for subsequent WebSocket authentication.
        """
        import hashlib
        import sys
        from datetime import datetime, timezone
        from pathlib import Path

        # Ensure the generated protobuf stubs are importable.
        # The stubs use `from agent.v1 import ...` which requires the gen/ dir on sys.path.
        _gen_path = str(Path(__file__).parent / "gen")
        if _gen_path not in sys.path:
            sys.path.insert(0, _gen_path)

        import grpc
        from agent.v1 import agent_pb2, phonebook_pb2_grpc  # type: ignore[import]

        ts = datetime.now(timezone.utc).isoformat()

        # Registration signature: SHA-256(did || public_key || timestamp)
        digest = hashlib.sha256(
            self.identity.did.encode()
            + self.identity.public_key_b64.encode()
            + ts.encode()
        ).digest()
        signature = self.identity.sign(digest)

        req = agent_pb2.RegisterAgentRequest(
            identity=agent_pb2.AgentIdentity(
                did=self.identity.did,
                public_key=self.identity.public_key_b64,
                display_name=self.config.display_name or self.identity.did,
                type=(
                    agent_pb2.AGENT_TYPE_COMPANY
                    if self.config.agent_type in {"business", "company"}
                    else agent_pb2.AGENT_TYPE_USER
                ),
                region=self.config.region,
                capabilities=self.config.capabilities,
            ),
            endpoint=agent_pb2.AgentEndpoint(
                ws_url=self.config.node_url,
                grpc_addr="",
                protocol_version="0.1",
            ),
            timestamp=ts,
            signature=signature,
        )

        # Run the synchronous gRPC call off the event loop to avoid blocking.
        def _register() -> str:
            channel = grpc.insecure_channel(self.config.phonebook_grpc_addr)
            try:
                stub = phonebook_pb2_grpc.PhonebookServiceStub(channel)
                metadata = None
                if self.config.auth_bearer_token:
                    metadata = (
                        ("authorization", f"Bearer {self.config.auth_bearer_token}"),
                    )
                resp = stub.RegisterAgent(req, timeout=10, metadata=metadata)
                return resp.session_token
            finally:
                channel.close()

        loop = asyncio.get_event_loop()
        token = await loop.run_in_executor(None, _register)
        logger.info("registered with phonebook — agent_did=%s", self.identity.did)
        return token
