"""B2Alpha CLI.

A terminal-first interface for onboarding and messaging on the B2Alpha network.
"""

from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

if TYPE_CHECKING:
    from b2alpha.identity import AgentIdentity

DEFAULT_KEY_PATH = Path("~/.b2alpha/agent.pem")
DEFAULT_NODE_URL = "wss://node.b2alpha.ai/v1/connect"
DEFAULT_PHONEBOOK_ADDR = "localhost:9091"
DEFAULT_AUTH_PATH = Path("~/.b2alpha/auth.json")
DEFAULT_PROFILE_PATH = Path("~/.b2alpha/profile.json")


def _cli_version() -> str:
    try:
        return metadata.version("b2alpha")
    except metadata.PackageNotFoundError:
        return "0.1.0-dev"


def _expand_path(path_value: str) -> Path:
    return Path(path_value).expanduser()


def _ensure_generated_proto_imports() -> None:
    gen_path = str(Path(__file__).parent / "gen")
    if gen_path not in sys.path:
        sys.path.insert(0, gen_path)


def _load_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _prompt_text(message: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    response = input(f"{message}{suffix}: ").strip()
    return response or default


def _prompt_choice(message: str, choices: list[str], default: str) -> str:
    choice_set = {c.lower() for c in choices}
    while True:
        value = _prompt_text(message, default=default).lower()
        if value in choice_set:
            return value
        print(f"Please choose one of: {', '.join(choices)}")


def _is_interactive_terminal() -> bool:
    return sys.stdin.isatty() and sys.stdout.isatty()


def _format_payload(payload: bytes) -> str:
    if not payload:
        return "<empty>"
    try:
        text = payload.decode("utf-8")
        if len(text) > 360:
            return f"{text[:360]}..."
        return text
    except UnicodeDecodeError:
        return f"<{len(payload)} bytes>"


def _parse_params(items: list[str]) -> dict[str, str]:
    params: dict[str, str] = {}
    for raw in items:
        if "=" not in raw:
            raise ValueError(f"invalid --param value '{raw}', expected KEY=VALUE")
        key, value = raw.split("=", 1)
        key = key.strip()
        if not key:
            raise ValueError("parameter key cannot be empty")
        params[key] = value.strip()
    return params


def _load_identity(key_path: Path) -> AgentIdentity:
    from b2alpha.identity import AgentIdentity

    if not key_path.exists():
        raise FileNotFoundError(
            f"key not found at {key_path}. Run `b2alpha init --key-path {key_path}` first."
        )
    return AgentIdentity.from_pem(key_path)


def cmd_init(args: argparse.Namespace) -> int:
    from b2alpha.identity import generate_keypair

    key_path = _expand_path(args.key_path)
    if key_path.exists() and not args.force:
        print(
            f"Key already exists at {key_path}. Use --force to overwrite.",
            file=sys.stderr,
        )
        return 1

    identity = generate_keypair(output_path=key_path)
    print(f"DID: {identity.did}")
    print(f"KEY: {key_path}")
    return 0


def cmd_did(args: argparse.Namespace) -> int:
    key_path = _expand_path(args.key_path)
    try:
        identity = _load_identity(key_path)
    except Exception as exc:  # pragma: no cover - user environment dependent
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    print(identity.did)
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    _ensure_generated_proto_imports()
    try:
        import grpc
        from agent.v1 import phonebook_pb2, phonebook_pb2_grpc  # type: ignore[import]
    except Exception as exc:  # pragma: no cover - import environment dependent
        print(f"Error importing phonebook stubs: {exc}", file=sys.stderr)
        return 2

    channel = grpc.insecure_channel(args.phonebook_addr)
    try:
        stub = phonebook_pb2_grpc.PhonebookServiceStub(channel)
        req = phonebook_pb2.SearchAgentsRequest(
            query=args.query,
            page_size=args.limit,
        )
        resp = stub.SearchAgents(req, timeout=args.timeout)
    except Exception as exc:  # pragma: no cover - network dependent
        print(f"Search failed: {exc}", file=sys.stderr)
        return 2
    finally:
        channel.close()

    if not resp.records:
        print("No agents found.")
        return 0

    for rec in resp.records:
        name = rec.identity.display_name or "<unnamed>"
        caps = ", ".join(rec.identity.capabilities) if rec.identity.capabilities else "none"
        print(rec.identity.did)
        print(f"  name: {name}")
        print(f"  capabilities: {caps}")
    return 0


async def _run_send(args: argparse.Namespace) -> int:
    from b2alpha.agent import Agent
    from b2alpha.config import AgentConfig
    from b2alpha.oauth import load_auth_data

    key_path = _expand_path(args.key_path)
    profile = _load_json(_expand_path(args.profile_file))
    auth_data = load_auth_data(_expand_path(args.auth_file)) or {}
    supabase = auth_data.get("supabase") if isinstance(auth_data, dict) else {}
    auth_token = ""
    if isinstance(supabase, dict):
        auth_token = str(supabase.get("access_token") or "")

    try:
        identity = _load_identity(key_path)
        params = _parse_params(args.param)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    config = AgentConfig(
        did=identity.did,
        private_key_path=key_path,
        node_url=args.node_url,
        phonebook_grpc_addr=args.phonebook_addr,
        request_timeout=args.timeout,
        display_name=str(profile.get("display_name", "")),
        agent_type=str(profile.get("agent_type", "user")),
        region=str(profile.get("region", "")),
        capabilities=list(profile.get("capabilities", [])),
        auth_bearer_token=auth_token,
    )
    client = Agent(config, identity=identity)

    try:
        async with client:
            response = await client.send(
                to=args.to,
                intent=args.intent,
                params=params,
                natural_language=args.message,
                wait_for_response=not args.no_wait,
                response_timeout=args.timeout,
            )
    except Exception as exc:  # pragma: no cover - network dependent
        print(f"Send failed: {exc}", file=sys.stderr)
        return 2

    print(f"from: {identity.did}")
    print(f"to: {args.to}")
    print(f"intent: {args.intent}")
    if args.no_wait:
        print("status: sent (not waiting for response)")
        return 0

    if response is None:
        print("status: sent")
        return 0

    print(f"response_from: {response.sender_did}")
    print(f"correlation_id: {response.correlation_id}")
    print(f"payload: {_format_payload(response.payload)}")
    return 0


def cmd_send(args: argparse.Namespace) -> int:
    try:
        return asyncio.run(_run_send(args))
    except KeyboardInterrupt:
        print("Cancelled.", file=sys.stderr)
        return 130


def cmd_register(args: argparse.Namespace) -> int:
    from b2alpha.identity import generate_keypair
    from b2alpha.oauth import load_auth_data

    _ensure_generated_proto_imports()
    try:
        import grpc
        from agent.v1 import agent_pb2, phonebook_pb2_grpc  # type: ignore[import]
    except Exception as exc:  # pragma: no cover - import environment dependent
        print(f"Error importing phonebook stubs: {exc}", file=sys.stderr)
        return 2

    key_path = _expand_path(args.key_path)
    profile_path = _expand_path(args.profile_file)
    auth_file = _expand_path(args.auth_file)

    if not key_path.exists():
        identity = generate_keypair(output_path=key_path)
    else:
        identity = _load_identity(key_path)

    auth_data = load_auth_data(auth_file) or {}
    supabase = auth_data.get("supabase") or {}
    supabase_user = supabase.get("user") if isinstance(supabase, dict) else {}

    if not args.allow_unauthenticated:
        if not isinstance(supabase, dict) or not supabase.get("access_token"):
            print(
                "Error: You must login first with Supabase-backed Google auth.\n"
                "Run: b2alpha login google --client-id <google-oauth-client-id> "
                "--supabase-url <url> --supabase-anon-key <anon-key>",
                file=sys.stderr,
            )
            return 1
    auth_token = str(supabase.get("access_token") or "") if isinstance(supabase, dict) else ""

    display_name = args.display_name
    if not display_name and isinstance(supabase_user, dict):
        display_name = str(
            supabase_user.get("full_name")
            or supabase_user.get("name")
            or supabase_user.get("email")
            or ""
        )
    if not display_name:
        display_name = identity.did

    capabilities = [c.strip() for c in args.capability if c.strip()]
    ts = datetime.now(timezone.utc).isoformat()
    digest = hashlib.sha256(
        identity.did.encode() + identity.public_key_b64.encode() + ts.encode()
    ).digest()
    signature = identity.sign(digest)

    agent_type = args.type.lower()
    type_enum = (
        agent_pb2.AGENT_TYPE_COMPANY
        if agent_type in {"business", "company"}
        else agent_pb2.AGENT_TYPE_USER
    )

    req = agent_pb2.RegisterAgentRequest(
        identity=agent_pb2.AgentIdentity(
            did=identity.did,
            public_key=identity.public_key_b64,
            display_name=display_name,
            type=type_enum,
            region=args.region,
            capabilities=capabilities,
        ),
        endpoint=agent_pb2.AgentEndpoint(
            ws_url=args.node_url,
            grpc_addr="",
            protocol_version="0.1",
        ),
        timestamp=ts,
        signature=signature,
    )

    channel = grpc.insecure_channel(args.phonebook_addr)
    try:
        stub = phonebook_pb2_grpc.PhonebookServiceStub(channel)
        metadata = None
        if auth_token:
            metadata = (
                ("authorization", f"Bearer {auth_token}"),
            )
        resp = stub.RegisterAgent(req, timeout=args.timeout, metadata=metadata)
    except Exception as exc:  # pragma: no cover - network dependent
        print(f"Registration failed: {exc}", file=sys.stderr)
        return 2
    finally:
        channel.close()

    profile = {
        "did": identity.did,
        "display_name": display_name,
        "agent_type": "business" if agent_type in {"business", "company"} else "user",
        "region": args.region,
        "capabilities": capabilities,
        "node_url": args.node_url,
        "phonebook_addr": args.phonebook_addr,
        "session_token": resp.session_token,
        "agent_id": resp.agent_id,
        "routing_key": resp.routing_key,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    _write_json(profile_path, profile)

    print("Registered on B2Alpha.")
    print(f"DID: {identity.did}")
    print(f"Type: {profile['agent_type']}")
    print(f"Profile: {profile_path}")
    return 0


def cmd_login_google(args: argparse.Namespace) -> int:
    from b2alpha.oauth import login_google_device_flow

    client_id = args.client_id or os.environ.get("B2A_GOOGLE_CLIENT_ID", "")
    if not client_id:
        print(
            "Error: missing Google OAuth client ID. Set --client-id or B2A_GOOGLE_CLIENT_ID.",
            file=sys.stderr,
        )
        return 1

    try:
        supabase_url = args.supabase_url or os.environ.get("B2A_SUPABASE_URL", "")
        supabase_anon_key = args.supabase_anon_key or os.environ.get("B2A_SUPABASE_ANON_KEY", "")
        result = login_google_device_flow(
            client_id=client_id,
            scopes=args.scope,
            auth_file=_expand_path(args.auth_file),
            open_browser=not args.no_browser,
            timeout_seconds=args.timeout,
            supabase_url=supabase_url or None,
            supabase_anon_key=supabase_anon_key or None,
            require_supabase=not args.google_only,
        )
    except Exception as exc:  # pragma: no cover - network/user dependent
        print(f"Login failed: {exc}", file=sys.stderr)
        return 2

    print("Google login complete.")
    if result.email:
        print(f"Email: {result.email}")
    if result.subject:
        print(f"Subject: {result.subject}")
    print(f"Saved: {result.auth_file}")
    return 0


def cmd_auth_status(args: argparse.Namespace) -> int:
    from b2alpha.oauth import load_auth_data

    auth_file = _expand_path(args.auth_file)
    data = load_auth_data(auth_file)
    if not data:
        print(f"No auth profile found at {auth_file}.")
        return 1

    claims = data.get("claims", {})
    supabase = data.get("supabase") or {}
    supabase_user = supabase.get("user") if isinstance(supabase, dict) else {}
    print(f"Provider: {data.get('provider', 'unknown')}")
    if claims.get("email"):
        print(f"Email: {claims['email']}")
    if claims.get("sub"):
        print(f"Subject: {claims['sub']}")
    if isinstance(supabase_user, dict) and supabase_user.get("id"):
        print(f"Supabase User ID: {supabase_user['id']}")
    if isinstance(supabase_user, dict) and supabase_user.get("email"):
        print(f"Supabase Email: {supabase_user['email']}")
    print(f"Auth file: {auth_file}")
    return 0


def cmd_logout(args: argparse.Namespace) -> int:
    from b2alpha.oauth import clear_auth_data

    auth_file = _expand_path(args.auth_file)
    clear_auth_data(auth_file)
    print(f"Logged out. Removed {auth_file}")
    return 0


def cmd_setup(args: argparse.Namespace) -> int:
    if not _is_interactive_terminal():
        print(
            "Setup wizard requires an interactive terminal.\n"
            "Run manually: b2alpha setup",
            file=sys.stderr,
        )
        return 1

    key_path = _expand_path(args.key_path)
    auth_file = _expand_path(args.auth_file)
    profile_file = _expand_path(args.profile_file)

    print("B2Alpha first-time setup")
    print("------------------------")

    if not key_path.exists():
        print("Creating your local DID key...")
        init_rc = cmd_init(argparse.Namespace(key_path=str(key_path), force=False))
        if init_rc != 0:
            return init_rc
    else:
        print(f"Found existing key: {key_path}")

    google_client_id = args.client_id or os.environ.get("B2A_GOOGLE_CLIENT_ID", "")
    supabase_url = args.supabase_url or os.environ.get("B2A_SUPABASE_URL", "")
    supabase_anon_key = args.supabase_anon_key or os.environ.get("B2A_SUPABASE_ANON_KEY", "")

    google_client_id = _prompt_text("Google OAuth client ID", default=google_client_id)
    supabase_url = _prompt_text("Supabase URL", default=supabase_url)
    supabase_anon_key = _prompt_text("Supabase anon key", default=supabase_anon_key)

    if not google_client_id or not supabase_url or not supabase_anon_key:
        print(
            "Google client ID, Supabase URL, and Supabase anon key are required.",
            file=sys.stderr,
        )
        return 1

    print("\nStep 1/2: Sign in with Google")
    login_rc = cmd_login_google(
        argparse.Namespace(
            client_id=google_client_id,
            scope=["openid", "email", "profile"],
            auth_file=str(auth_file),
            supabase_url=supabase_url,
            supabase_anon_key=supabase_anon_key,
            google_only=False,
            no_browser=args.no_browser,
            timeout=args.timeout,
        )
    )
    if login_rc != 0:
        return login_rc

    print("\nStep 2/2: Register your profile")
    reg_type = args.type or _prompt_choice(
        "Register as (user/business)",
        choices=["user", "business"],
        default="user",
    )
    display_name = args.display_name or _prompt_text("Display name", default="")
    region = args.region or _prompt_text("Region (optional, e.g. US)", default="")
    capability_text = ",".join(args.capability) if args.capability else ""
    capability_text = _prompt_text(
        "Capabilities (comma-separated, optional)",
        default=capability_text,
    )
    capabilities = [c.strip() for c in capability_text.split(",") if c.strip()]

    register_rc = cmd_register(
        argparse.Namespace(
            type=reg_type,
            display_name=display_name,
            region=region,
            capability=capabilities,
            key_path=str(key_path),
            node_url=args.node_url,
            phonebook_addr=args.phonebook_addr,
            timeout=args.timeout,
            auth_file=str(auth_file),
            profile_file=str(profile_file),
            allow_unauthenticated=False,
        )
    )
    if register_rc != 0:
        return register_rc

    print("\nSetup complete. You can now use `b2alpha send` and `b2alpha search`.")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="b2alpha",
        description=(
            "CLI for agent-to-agent messaging and discovery on B2Alpha. "
            "For first-time onboarding, run `b2alpha setup`."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {_cli_version()}",
    )

    subparsers = parser.add_subparsers(dest="command")

    init_parser = subparsers.add_parser("init", help="Generate and store a local DID keypair.")
    init_parser.add_argument("--key-path", default=str(DEFAULT_KEY_PATH))
    init_parser.add_argument("--force", action="store_true", help="Overwrite existing key file.")
    init_parser.set_defaults(func=cmd_init)

    did_parser = subparsers.add_parser("did", help="Print DID from an existing private key.")
    did_parser.add_argument("--key-path", default=str(DEFAULT_KEY_PATH))
    did_parser.set_defaults(func=cmd_did)

    search_parser = subparsers.add_parser(
        "search", help="Search the phonebook for discoverable agents."
    )
    search_parser.add_argument("query", help="Natural language search query.")
    search_parser.add_argument("--limit", type=int, default=10)
    search_parser.add_argument("--timeout", type=float, default=10.0)
    search_parser.add_argument("--phonebook-addr", default=DEFAULT_PHONEBOOK_ADDR)
    search_parser.set_defaults(func=cmd_search)

    register_parser = subparsers.add_parser(
        "register",
        help="Register this DID as a user or business on B2Alpha.",
    )
    register_parser.add_argument(
        "--type",
        choices=["user", "business"],
        default="user",
        help="Registration type.",
    )
    register_parser.add_argument(
        "--display-name",
        default="",
        help="Display name in the phonebook.",
    )
    register_parser.add_argument(
        "--region",
        default="",
        help="Region code (example: US).",
    )
    register_parser.add_argument(
        "--capability",
        action="append",
        default=[],
        help="Capability tag. Repeat for multiple values.",
    )
    register_parser.add_argument("--key-path", default=str(DEFAULT_KEY_PATH))
    register_parser.add_argument("--node-url", default=DEFAULT_NODE_URL)
    register_parser.add_argument("--phonebook-addr", default=DEFAULT_PHONEBOOK_ADDR)
    register_parser.add_argument("--timeout", type=float, default=10.0)
    register_parser.add_argument("--auth-file", default=str(DEFAULT_AUTH_PATH))
    register_parser.add_argument("--profile-file", default=str(DEFAULT_PROFILE_PATH))
    register_parser.add_argument(
        "--allow-unauthenticated",
        action="store_true",
        help="Allow registration without Supabase-authenticated Google login.",
    )
    register_parser.set_defaults(func=cmd_register)

    send_parser = subparsers.add_parser("send", help="Send a message to another DID.")
    send_parser.add_argument("--to", required=True, help="Recipient DID.")
    send_parser.add_argument("--intent", required=True, help="Intent string (example: book.flight).")
    send_parser.add_argument("--message", default="", help="Natural-language payload text.")
    send_parser.add_argument(
        "--param",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Structured parameter. Repeat for multiple values.",
    )
    send_parser.add_argument("--key-path", default=str(DEFAULT_KEY_PATH))
    send_parser.add_argument("--node-url", default=DEFAULT_NODE_URL)
    send_parser.add_argument("--phonebook-addr", default=DEFAULT_PHONEBOOK_ADDR)
    send_parser.add_argument("--profile-file", default=str(DEFAULT_PROFILE_PATH))
    send_parser.add_argument("--auth-file", default=str(DEFAULT_AUTH_PATH))
    send_parser.add_argument("--timeout", type=float, default=30.0)
    send_parser.add_argument(
        "--no-wait",
        action="store_true",
        help="Send without waiting for a correlated response.",
    )
    send_parser.set_defaults(func=cmd_send)

    login_parser = subparsers.add_parser(
        "login", help="Authenticate the CLI with external identity providers."
    )
    login_subparsers = login_parser.add_subparsers(dest="login_provider")

    google_login = login_subparsers.add_parser(
        "google",
        help="Sign in with Google using OAuth device flow.",
    )
    google_login.add_argument(
        "--client-id",
        default="",
        help="Google OAuth client ID (or set B2A_GOOGLE_CLIENT_ID).",
    )
    google_login.add_argument(
        "--scope",
        action="append",
        default=["openid", "email", "profile"],
        help="OAuth scope. Repeat to add more scopes.",
    )
    google_login.add_argument(
        "--auth-file",
        default=str(DEFAULT_AUTH_PATH),
        help="Path to store login tokens.",
    )
    google_login.add_argument(
        "--supabase-url",
        default="",
        help="Supabase project URL (or set B2A_SUPABASE_URL).",
    )
    google_login.add_argument(
        "--supabase-anon-key",
        default="",
        help="Supabase anon key (or set B2A_SUPABASE_ANON_KEY).",
    )
    google_login.add_argument(
        "--google-only",
        action="store_true",
        help="Skip Supabase token exchange and store Google tokens only.",
    )
    google_login.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not auto-open browser; print verification URL/code only.",
    )
    google_login.add_argument(
        "--timeout",
        type=int,
        default=300,
        help="Authorization timeout in seconds.",
    )
    google_login.set_defaults(func=cmd_login_google)

    auth_status = subparsers.add_parser(
        "auth-status",
        help="Show saved authentication profile details.",
    )
    auth_status.add_argument(
        "--auth-file",
        default=str(DEFAULT_AUTH_PATH),
        help="Path to stored auth profile.",
    )
    auth_status.set_defaults(func=cmd_auth_status)

    logout_parser = subparsers.add_parser(
        "logout",
        help="Remove locally saved authentication profile.",
    )
    logout_parser.add_argument(
        "--auth-file",
        default=str(DEFAULT_AUTH_PATH),
        help="Path to stored auth profile.",
    )
    logout_parser.set_defaults(func=cmd_logout)

    setup_parser = subparsers.add_parser(
        "setup",
        help="First-time interactive onboarding: login and register profile.",
    )
    setup_parser.add_argument("--key-path", default=str(DEFAULT_KEY_PATH))
    setup_parser.add_argument("--auth-file", default=str(DEFAULT_AUTH_PATH))
    setup_parser.add_argument("--profile-file", default=str(DEFAULT_PROFILE_PATH))
    setup_parser.add_argument("--phonebook-addr", default=DEFAULT_PHONEBOOK_ADDR)
    setup_parser.add_argument("--node-url", default=DEFAULT_NODE_URL)
    setup_parser.add_argument("--timeout", type=int, default=300)
    setup_parser.add_argument(
        "--client-id",
        default="",
        help="Google OAuth client ID (or set B2A_GOOGLE_CLIENT_ID).",
    )
    setup_parser.add_argument(
        "--supabase-url",
        default="",
        help="Supabase project URL (or set B2A_SUPABASE_URL).",
    )
    setup_parser.add_argument(
        "--supabase-anon-key",
        default="",
        help="Supabase anon key (or set B2A_SUPABASE_ANON_KEY).",
    )
    setup_parser.add_argument(
        "--type",
        choices=["user", "business"],
        default=None,
        help="Preselect registration type.",
    )
    setup_parser.add_argument(
        "--display-name",
        default="",
        help="Pre-fill display name.",
    )
    setup_parser.add_argument(
        "--region",
        default="",
        help="Pre-fill region code.",
    )
    setup_parser.add_argument(
        "--capability",
        action="append",
        default=[],
        help="Pre-fill a capability tag. Repeat for multiple values.",
    )
    setup_parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not auto-open browser during Google login.",
    )
    setup_parser.set_defaults(func=cmd_setup)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    handler = getattr(args, "func", None)
    if handler is None:
        parser.print_help()
        return 1
    return int(handler(args))


if __name__ == "__main__":
    raise SystemExit(main())
