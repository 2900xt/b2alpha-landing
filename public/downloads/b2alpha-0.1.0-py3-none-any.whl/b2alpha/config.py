from pathlib import Path
from typing import Literal
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AgentConfig(BaseSettings):
    """Configuration for a B2Alpha agent connection.

    All fields can be set via environment variables prefixed ``B2A_``,
    e.g. ``B2A_NODE_URL=wss://node.b2alpha.ai/v1/connect``.
    """

    model_config = SettingsConfigDict(env_prefix="B2A_", env_file=".env")

    # Identity
    did: str = Field(..., description="Agent DID, e.g. did:b2a:z6Mk...")
    private_key_path: Path = Field(
        ..., description="Path to the Ed25519 private key PEM file"
    )
    display_name: str = Field(
        default="",
        description="Public display label for this agent.",
    )
    agent_type: Literal["user", "business", "company"] = Field(
        default="user",
        description="Agent profile type used during phonebook registration.",
    )
    region: str = Field(
        default="",
        description="Optional ISO region code (example: US).",
    )
    capabilities: list[str] = Field(
        default_factory=list,
        description="Capability tags for discovery search.",
    )
    auth_bearer_token: str = Field(
        default="",
        description="Optional bearer token forwarded during phonebook registration.",
    )

    # Network
    node_url: str = Field(
        default="wss://node.b2alpha.ai/v1/connect",
        description="WebSocket URL of the routing node",
    )
    phonebook_grpc_addr: str = Field(
        default="localhost:9091",
        description="host:port of the phonebook gRPC server (binary protocol)",
    )
    phonebook_url: str = Field(
        default="https://phonebook.b2alpha.ai",
        description="HTTP base URL of the phonebook (gRPC-Web / REST)",
    )

    # Timeouts (seconds)
    connect_timeout: float = Field(default=10.0)
    request_timeout: float = Field(default=30.0)
    heartbeat_interval: float = Field(default=30.0)

    # Delivery
    replay_undelivered: bool = Field(
        default=False,
        description="Reserved for future use (currently not implemented by the node)",
    )
