from pathlib import Path
from typing import Literal
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class AgentConfig(BaseSettings):
    """Configuration for a B2Alpha agent connection.

    All fields can be set via environment variables prefixed ``B2A_``,
    e.g. ``B2A_NODE_URL=ws://143.198.30.138:8080/v1/connect``.
    """

    model_config = SettingsConfigDict(env_prefix="B2A_", env_file=".env")

    # Identity
    did: str = Field(..., description="Agent DID, e.g. did:b2a:z6Mk...")
    private_key_path: Path = Field(
        ..., description="Path to the Ed25519 private key PEM file"
    )
    display_name: str = Field(
        default="",
        description="Public display label for this agent.",
    )
    agent_type: Literal["user", "business", "company"] = Field(
        default="user",
        description="Agent profile type used during phonebook registration.",
    )
    region: str = Field(
        default="",
        description="Optional ISO region code (example: US).",
    )
    capabilities: list[str] = Field(
        default_factory=list,
        description="Capability tags for discovery search.",
    )
    auth_bearer_token: str = Field(
        default="",
        description="Optional bearer token forwarded during phonebook registration.",
    )

    # Network
    node_url: str = Field(
        default="ws://143.198.30.138:8080/v1/connect",
        description="WebSocket URL of the routing node",
    )
    phonebook_grpc_addr: str = Field(
        default="143.198.30.138:9091",
        description="host:port of the phonebook gRPC server (binary protocol)",
    )
    phonebook_url: str = Field(
        default="http://143.198.30.138:8081",
        description="HTTP base URL of the phonebook (gRPC-Web / REST)",
    )

    # Timeouts (seconds)
    connect_timeout: float = Field(default=10.0)
    request_timeout: float = Field(default=30.0)
    heartbeat_interval: float = Field(default=30.0)

    # Authentication
    google_client_id: str = Field(
        default="430773753897-e217f01njne6lgbj2vpvkoet8sd3oj6g.apps.googleusercontent.com",
        description="Google OAuth Client ID for the Desktop flow.",
    )
    google_client_secret: str = Field(
        default="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",
        description="Google OAuth Client Secret (required for some Desktop flows).",
    )
    supabase_url: str = Field(
        default="https://lmrtjclgcaxzvghyosct.supabase.co",
        description="Supabase Project URL.",
    )
    supabase_anon_key: str = Field(
        default="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImxtcnRqY2xnY2F4enZnaHlvc2N0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzEzNDEwNzksImV4cCI6MjA4NjkxNzA3OX0.zwk92t0SnxkULjNY2XlbnW4_e9RoEzOyB9rdRe3AmWs",
        description="Supabase Anon Key (public).",
    )

    # Delivery
    replay_undelivered: bool = Field(
        default=False,
        description="Reserved for future use (currently not implemented by the node)",
    )
