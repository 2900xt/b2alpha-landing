"""Agent identity — Ed25519 keypair generation and DID derivation."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


@dataclass(frozen=True)
class AgentIdentity:
    """The cryptographic identity of an agent."""

    did: str
    public_key_b64: str  # Raw 32-byte Ed25519 pubkey, base64url-encoded
    private_key: Ed25519PrivateKey

    def sign(self, data: bytes) -> str:
        """Sign data and return the Ed25519 signature as base64url string."""
        sig = self.private_key.sign(data)
        return base64.urlsafe_b64encode(sig).rstrip(b"=").decode()

    @classmethod
    def from_pem(cls, pem_path: Path) -> "AgentIdentity":
        """Load an existing identity from a PEM private key file."""
        pem_bytes = pem_path.read_bytes()
        private_key = serialization.load_pem_private_key(pem_bytes, password=None)
        if not isinstance(private_key, Ed25519PrivateKey):
            raise ValueError("PEM file must contain an Ed25519 private key")
        return _build_identity(private_key)


def generate_keypair(output_path: Path | None = None) -> AgentIdentity:
    """Generate a new Ed25519 keypair and derive a DID.

    Args:
        output_path: If provided, writes the private key PEM to this path.

    Returns:
        A new AgentIdentity with a freshly generated DID.
    """
    private_key = Ed25519PrivateKey.generate()
    identity = _build_identity(private_key)

    if output_path is not None:
        pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_bytes(pem)
        output_path.chmod(0o600)

    return identity


def _build_identity(private_key: Ed25519PrivateKey) -> AgentIdentity:
    pub: Ed25519PublicKey = private_key.public_key()
    raw_pub = pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    # base64url-encode the raw 32-byte key (no padding)
    pub_b64 = base64.urlsafe_b64encode(raw_pub).rstrip(b"=").decode()

    # DID: did:b2a:z<base58btc(raw_pub)>
    did = _derive_did(raw_pub)

    return AgentIdentity(
        did=did,
        public_key_b64=pub_b64,
        private_key=private_key,
    )


def _derive_did(raw_public_key: bytes) -> str:
    """Derive a did:b2a DID from a raw Ed25519 public key.

    Uses base58btc encoding (multibase prefix 'z'), consistent with
    did:key and the W3C DID spec.
    """
    import hashlib

    # Multicodec prefix for Ed25519 public key: 0xed01
    prefixed = b"\xed\x01" + raw_public_key

    # base58btc encoding
    encoded = _base58_encode(prefixed)
    return f"did:b2a:z{encoded}"


_BASE58_ALPHABET = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"


def _base58_encode(data: bytes) -> str:
    count = 0
    for byte in data:
        if byte == 0:
            count += 1
        else:
            break

    num = int.from_bytes(data, "big")
    result = []
    while num > 0:
        num, remainder = divmod(num, 58)
        result.append(_BASE58_ALPHABET[remainder : remainder + 1])

    result.extend([b"1"] * count)
    return b"".join(reversed(result)).decode("ascii")
