"""Message types for agent-to-agent communication."""

from __future__ import annotations

import hashlib
import os
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import IntEnum
from typing import Any


def _uuid7() -> uuid.UUID:
    """Generate a UUID v7 (time-ordered, per RFC 9562).

    Layout (128 bits):
        48 bits — Unix timestamp in milliseconds
         4 bits — version (0b0111 = 7)
        12 bits — random
         2 bits — variant (0b10)
        62 bits — random
    """
    timestamp_ms = int(time.time() * 1000)
    rand_bytes = os.urandom(10)  # 80 random bits

    # Encode the 128-bit UUID
    uuid_int = (timestamp_ms & 0xFFFFFFFFFFFF) << 80  # bits 127..80
    uuid_int |= 0x7 << 76                              # version 7 in bits 79..76
    uuid_int |= (rand_bytes[0] & 0x0F) << 72           # rand_a (12 bits)
    uuid_int |= rand_bytes[1] << 64
    uuid_int |= 0b10 << 62                             # variant bits 63..62
    uuid_int |= int.from_bytes(rand_bytes[2:], "big") & 0x3FFFFFFFFFFFFFFF

    return uuid.UUID(int=uuid_int)


class MessageType(IntEnum):
    UNSPECIFIED = 0
    REQUEST = 1
    RESPONSE = 2
    TRANSACTION = 3
    ACK = 4
    ERROR = 5
    HANDSHAKE = 6


class DeliveryGuarantee(IntEnum):
    UNSPECIFIED = 0
    AT_MOST_ONCE = 1
    AT_LEAST_ONCE = 2
    EXACTLY_ONCE = 3


@dataclass
class AgentMessage:
    """The decrypted inner payload of an Envelope."""

    intent: str
    params: dict[str, str] = field(default_factory=dict)
    natural_language: str = ""

    def to_bytes(self) -> bytes:
        import json
        return json.dumps({
            "intent": self.intent,
            "params": self.params,
            "natural_language": self.natural_language,
        }).encode()


@dataclass
class Envelope:
    """The outer wrapper for every message on the network.

    Create via :meth:`Envelope.build` to ensure the message_id
    and timestamps are set correctly.
    """

    message_id: str
    sender_did: str
    recipient_did: str
    payload: bytes
    signature: str
    type: MessageType = MessageType.REQUEST
    delivery: DeliveryGuarantee = DeliveryGuarantee.AT_LEAST_ONCE
    correlation_id: str = ""
    routing_key: str = ""
    protocol_version: str = "0.1"
    hop_count: int = 0
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    expires_at: datetime | None = None

    @classmethod
    def build(
        cls,
        *,
        sender_did: str,
        recipient_did: str,
        message: AgentMessage,
        sign_fn: Any,  # callable(bytes) -> str
        correlation_id: str = "",
        delivery: DeliveryGuarantee = DeliveryGuarantee.AT_LEAST_ONCE,
        ttl_seconds: int = 300,
    ) -> "Envelope":
        """Construct, sign, and return a new Envelope."""
        from datetime import timedelta

        message_id = str(_uuid7())
        payload = message.to_bytes()
        created_at = datetime.now(timezone.utc)
        expires_at = created_at + timedelta(seconds=ttl_seconds)

        # Sign: SHA-256(message_id || sender_did || recipient_did || payload)
        digest = hashlib.sha256(
            message_id.encode()
            + sender_did.encode()
            + recipient_did.encode()
            + payload
        ).digest()
        signature = sign_fn(digest)

        return cls(
            message_id=message_id,
            sender_did=sender_did,
            recipient_did=recipient_did,
            payload=payload,
            signature=signature,
            correlation_id=correlation_id,
            delivery=delivery,
            created_at=created_at,
            expires_at=expires_at,
        )

    def to_dict(self) -> dict[str, Any]:
        """Serialize to a JSON-compatible dict for WebSocket transport.

        payload is base64-encoded to match Go's encoding/json default for []byte.
        """
        import base64
        return {
            "message_id": self.message_id,
            "correlation_id": self.correlation_id,
            "sender_did": self.sender_did,
            "recipient_did": self.recipient_did,
            "routing_key": self.routing_key,
            "type": int(self.type),
            "delivery": int(self.delivery),
            "payload": base64.b64encode(self.payload).decode(),
            "signature": self.signature,
            "protocol_version": self.protocol_version,
            "hop_count": self.hop_count,
            "created_at": self.created_at.isoformat(),
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        }
