"""OAuth helpers for B2Alpha CLI authentication flows."""

from __future__ import annotations

import base64
import json
import os
import time
import webbrowser
from dataclasses import dataclass
from pathlib import Path
from typing import Any

GOOGLE_DEVICE_CODE_URL = "https://oauth2.googleapis.com/device/code"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
DEFAULT_SCOPES = ["openid", "email", "profile"]
DEFAULT_AUTH_FILE = Path("~/.b2alpha/auth.json")


@dataclass(frozen=True)
class GoogleLoginResult:
    provider: str
    email: str | None
    subject: str | None
    auth_file: Path


def default_auth_file() -> Path:
    return DEFAULT_AUTH_FILE.expanduser()


def load_auth_data(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def clear_auth_data(path: Path) -> None:
    if path.exists():
        path.unlink()


def login_google_device_flow(
    *,
    client_id: str,
    scopes: list[str] | None = None,
    auth_file: Path | None = None,
    open_browser: bool = True,
    timeout_seconds: int = 300,
    supabase_url: str | None = None,
    supabase_anon_key: str | None = None,
    require_supabase: bool = True,
) -> GoogleLoginResult:
    import httpx

    if not client_id:
        raise ValueError("Google OAuth client ID is required.")

    resolved_scopes = scopes or DEFAULT_SCOPES
    auth_path = (auth_file or default_auth_file()).expanduser()

    with httpx.Client(timeout=15.0) as client:
        device_resp = client.post(
            GOOGLE_DEVICE_CODE_URL,
            data={
                "client_id": client_id,
                "scope": " ".join(resolved_scopes),
            },
            headers={"Accept": "application/json"},
        )
        device_resp.raise_for_status()
        device_data = device_resp.json()

        device_code = device_data["device_code"]
        user_code = device_data["user_code"]
        verification_uri = device_data.get("verification_uri", "")
        verification_uri_complete = device_data.get("verification_uri_complete")
        interval = int(device_data.get("interval", 5))
        expires_in = int(device_data.get("expires_in", timeout_seconds))

        if open_browser and verification_uri_complete:
            webbrowser.open(verification_uri_complete)

        print("Google login required.")
        if verification_uri_complete:
            print(f"Open: {verification_uri_complete}")
        elif verification_uri:
            print(f"Open: {verification_uri}")
        print(f"Code: {user_code}")

        started = time.time()
        poll_interval = max(1, interval)

        while True:
            if time.time() - started > min(timeout_seconds, expires_in):
                raise TimeoutError("Timed out waiting for Google device authorization.")

            token_resp = client.post(
                GOOGLE_TOKEN_URL,
                data={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={"Accept": "application/json"},
            )
            token_data = token_resp.json()

            if token_resp.status_code == 200 and "access_token" in token_data:
                break

            error = token_data.get("error", "")
            if error == "authorization_pending":
                time.sleep(poll_interval)
                continue
            if error == "slow_down":
                poll_interval += 2
                time.sleep(poll_interval)
                continue
            if error in {"expired_token", "access_denied"}:
                raise RuntimeError(f"Google login failed: {error}")
            raise RuntimeError(f"Google token exchange failed: {token_data}")

    claims = _decode_id_token_claims(token_data.get("id_token"))
    email = claims.get("email")
    subject = claims.get("sub")

    supabase_session: dict[str, Any] | None = None
    if supabase_url and supabase_anon_key:
        supabase_session = exchange_google_id_token_for_supabase(
            supabase_url=supabase_url,
            supabase_anon_key=supabase_anon_key,
            id_token=token_data.get("id_token"),
        )
    elif require_supabase:
        raise ValueError(
            "Supabase login is required. Set supabase_url/supabase_anon_key or use Google-only mode."
        )

    record = {
        "provider": "google",
        "issued_at": int(time.time()),
        "access_token": token_data.get("access_token"),
        "refresh_token": token_data.get("refresh_token"),
        "id_token": token_data.get("id_token"),
        "token_type": token_data.get("token_type"),
        "expires_in": token_data.get("expires_in"),
        "scope": token_data.get("scope", " ".join(resolved_scopes)),
        "claims": claims,
        "supabase": supabase_session,
    }

    _write_secure_json(auth_path, record)

    return GoogleLoginResult(
        provider="google",
        email=_pick_email(email, supabase_session),
        subject=_pick_subject(subject, supabase_session),
        auth_file=auth_path,
    )


def login_google_desktop(
    *,
    client_id: str,
    client_secret: str | None = None,
    scopes: list[str] | None = None,
    auth_file: Path | None = None,
    timeout_seconds: int = 300,
    supabase_url: str | None = None,
    supabase_anon_key: str | None = None,
    require_supabase: bool = True,
) -> GoogleLoginResult:
    """Perform Google OAuth 2.0 PKCE flow with local redirect server."""
    import hashlib
    import secrets
    import socket
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import parse_qs, urlencode, urlparse

    import httpx

    if not client_id:
        raise ValueError("Google OAuth client ID is required.")

    resolved_scopes = scopes or DEFAULT_SCOPES
    auth_path = (auth_file or default_auth_file()).expanduser()

    # 1. Generate PKCE Code Verifier, Challenge, and State
    code_verifier = secrets.token_urlsafe(64)
    code_challenge = (
        base64.urlsafe_b64encode(hashlib.sha256(code_verifier.encode("ascii")).digest())
        .decode("ascii")
        .rstrip("=")
    )
    state = secrets.token_urlsafe(16)

    # 2. Find a free port and start server
    # Allow OS to pick a random free port by binding to 0
    # Note: Google Desktop clients allow dynamic localhost ports.
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    redirect_uri = f"http://127.0.0.1:{port}/"
    auth_code: str | None = None
    auth_state: str | None = None
    server_error: str | None = None

    class LoginHandler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            nonlocal auth_code, auth_state, server_error
            try:
                params = parse_qs(urlparse(self.path).query)
                if "error" in params:
                    server_error = params["error"][0]
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(b"<h1>Login Failed</h1><p>You can close this window.</p>")
                    return

                if "code" in params and "state" in params:
                    auth_code = params["code"][0]
                    auth_state = params["state"][0]
                    self.send_response(200)
                    self.send_header("Content-type", "text/html")
                    self.end_headers()
                    self.wfile.write(
                        b"<h1>Login Successful</h1><p>You can close this window and return to the terminal.</p>"
                        b"<script>window.close()</script>"
                    )
                else:
                    self.send_error(400, "Missing code or state param")
            except Exception as e:
                server_error = str(e)

        def log_message(self, format: str, *args: Any) -> None:
            pass  # Suppress server logs

    server = HTTPServer(("127.0.0.1", port), LoginHandler)

    # 3. Construct Auth URL and Open Browser
    auth_params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": " ".join(resolved_scopes),
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "state": state,
        "access_type": "offline",  # To get refresh token
    }
    auth_url = f"https://accounts.google.com/o/oauth2/v2/auth?{urlencode(auth_params)}"

    print("Opening browser for Google login...")
    webbrowser.open(auth_url)

    # 4. Wait for Callback
    server.timeout = timeout_seconds
    server.handle_request()  # Handle one request
    server.server_close()

    if server_error:
        raise RuntimeError(f"Authentication failed during callback: {server_error}")
    if not auth_code:
        raise RuntimeError("Authentication timed out or no code received.")
    if not auth_state or auth_state != state:
        raise RuntimeError("Authentication failed: State mismatch (possible CSRF attack).")
    
    # 5. Exchange Code for Tokens
    print("Completing login...")
    data = {
        "client_id": client_id,
        "code": auth_code,
        "code_verifier": code_verifier,
        "redirect_uri": redirect_uri,
        "grant_type": "authorization_code",
    }
    if client_secret:
        data["client_secret"] = client_secret

    with httpx.Client(timeout=15.0) as client:
        token_resp = client.post(
            GOOGLE_TOKEN_URL,
            data=data,
            headers={"Accept": "application/json"},
        )
        if token_resp.status_code != 200:
            raise RuntimeError(f"Token exchange failed: {token_resp.text}")
        token_data = token_resp.json()

    claims = _decode_id_token_claims(token_data.get("id_token"))
    email = claims.get("email")
    subject = claims.get("sub")

    supabase_session: dict[str, Any] | None = None
    if supabase_url and supabase_anon_key:
        supabase_session = exchange_google_id_token_for_supabase(
            supabase_url=supabase_url,
            supabase_anon_key=supabase_anon_key,
            id_token=token_data.get("id_token"),
        )
    elif require_supabase:
        raise ValueError(
            "Supabase login is required. Set supabase_url/supabase_anon_key or use Google-only mode."
        )

    record = {
        "provider": "google",
        "issued_at": int(time.time()),
        "access_token": token_data.get("access_token"),
        "refresh_token": token_data.get("refresh_token"),
        "id_token": token_data.get("id_token"),
        "token_type": token_data.get("token_type"),
        "expires_in": token_data.get("expires_in"),
        "scope": token_data.get("scope", " ".join(resolved_scopes)),
        "claims": claims,
        "supabase": supabase_session,
    }

    _write_secure_json(auth_path, record)

    return GoogleLoginResult(
        provider="google",
        email=_pick_email(email, supabase_session),
        subject=_pick_subject(subject, supabase_session),
        auth_file=auth_path,
    )


def exchange_google_id_token_for_supabase(
    *,
    supabase_url: str,
    supabase_anon_key: str,
    id_token: str | None,
) -> dict[str, Any]:
    import httpx

    if not id_token:
        raise ValueError("Google ID token missing; cannot exchange with Supabase.")

    url = f"{supabase_url.rstrip('/')}/auth/v1/token?grant_type=id_token"
    with httpx.Client(timeout=20.0) as client:
        resp = client.post(
            url,
            json={
                "provider": "google",
                "id_token": id_token,
            },
            headers={
                "apikey": supabase_anon_key,
                "Authorization": f"Bearer {supabase_anon_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
        )

    if resp.status_code >= 400:
        raise RuntimeError(f"Supabase token exchange failed: {resp.status_code} {resp.text}")

    data = resp.json()
    return {
        "access_token": data.get("access_token"),
        "refresh_token": data.get("refresh_token"),
        "token_type": data.get("token_type"),
        "expires_in": data.get("expires_in"),
        "expires_at": data.get("expires_at"),
        "user": data.get("user"),
    }


def _decode_id_token_claims(id_token: str | None) -> dict[str, Any]:
    if not id_token:
        return {}

    parts = id_token.split(".")
    if len(parts) < 2:
        return {}

    payload = parts[1]
    padded = payload + "=" * (-len(payload) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded.encode("utf-8"))
        return json.loads(decoded.decode("utf-8"))
    except (ValueError, json.JSONDecodeError):
        return {}


def _pick_email(google_email: str | None, supabase_session: dict[str, Any] | None) -> str | None:
    if supabase_session:
        user = supabase_session.get("user") or {}
        if isinstance(user, dict) and user.get("email"):
            return str(user["email"])
    return google_email


def _pick_subject(google_subject: str | None, supabase_session: dict[str, Any] | None) -> str | None:
    if supabase_session:
        user = supabase_session.get("user") or {}
        if isinstance(user, dict) and user.get("id"):
            return str(user["id"])
    return google_subject


def _write_secure_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        # Best effort on platforms where chmod may fail.
        pass
